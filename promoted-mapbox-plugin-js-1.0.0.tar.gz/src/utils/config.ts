export const sourceId = 'promoted-source';
export const layerId = 'promoted-layer';

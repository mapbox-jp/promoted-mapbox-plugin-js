# Promoted Mapbox Plugin JS

## Install libraries

```bash
npm install
```

## Build as production environment

```bash
npm run build
```

## Build as development environment

```bash
npm run build:dev
```
